import React from 'react'
import styles from "./chart.module.scss"

const Chart = () => {
  return (
    <div>Chart</div>
  )
}

export default Chart