import { useSelector } from 'react-redux'
import { selectEmail } from '../../redux/slice/authSlice'
import { Link } from 'react-router-dom'


const AdminOlnlyRoute = ({ children }) => {

    const userEmail = useSelector(selectEmail)

    if (userEmail === "abdullah@gmail.com" || userEmail === "admin@gmail.com") {
        return children
    }
    return (
        <section style={{ height: "80vh" }}>
            <div className='container'>
                <h2>OOOPPSS... Error 404. Page Not Found.</h2>
                <p>Seems You are Lost!!!!</p>
                <br />
                <Link to="/">
                    <button className='--btn'>&larr; Back To Home</button>
                </Link>
            </div>
        </section>
    );
}

export const AdminOlnlyLink = ({ children }) => {

    const userEmail = useSelector(selectEmail)

    if (userEmail === "abdullah@gmail.com" || userEmail === "admin@gmail.com") {
        return children
    }
    return null;
}

export default AdminOlnlyRoute