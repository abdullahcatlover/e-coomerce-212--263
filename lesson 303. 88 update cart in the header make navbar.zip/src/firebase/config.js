import { initializeApp } from "firebase/app";
import {getAuth} from 'firebase/auth'
import {getFirestore, deleteObject} from 'firebase/firestore'
import {getStorage} from 'firebase/storage'

export const firebaseConfig = {
  apiKey: "AIzaSyC8GL_YnN1WRwXVllNIsrV9KKmvV36Wlmk",
  authDomain: "e-commerce-trust.firebaseapp.com",
  projectId: "e-commerce-trust",
  storageBucket: "e-commerce-trust.appspot.com",
  messagingSenderId: "257790546011",
  appId: "1:257790546011:web:219b3a3eef312067e2ef7e"
};


//initialize App
const app = initializeApp(firebaseConfig);

export const auth = getAuth(app)
export const db = getFirestore(app)
export const storage = getStorage(app)

export default app;