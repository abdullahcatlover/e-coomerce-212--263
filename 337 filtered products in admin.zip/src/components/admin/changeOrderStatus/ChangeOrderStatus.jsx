import { useState } from "react"
import React from 'react'
import styles from "./changeOrderStatus.module.scss"
import Loader from "../../loader/Loader"
import Card from "../../card/Card"
import { Timestamp, doc, setDoc } from "firebase/firestore"
import { db } from "../../../firebase/config"
import { toast } from "react-toastify"
import { Navigate, useNavigate } from "react-router-dom"

const ChangeOrderStatus = ({order, id}) => {
  const [status, setStatus] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const navigate = useNavigate()

  const editOrder = (e, id) => {
    e.preventDefault();
    setIsLoading(true);

    
    const {userID, userEmail, orderDate, orderTime, 
      orderAmount, cartItems, shippingAddress, createdAt} = order


    const orderConfig = {
      userID,
      userEmail,
      orderDate,
      orderTime,
      orderAmount,
      orderStatus: status,
      cartItems,
      shippingAddress,
      createdAt,
      editedAt: Timestamp.now().toDate(),
    }

    try {

      setDoc(doc(db, "orders", id), orderConfig)


      setIsLoading(false);
      toast.success("Order status has been changed successfully");
      navigate("/admin/orders");

    } catch (error) {
      setIsLoading(false);
      toast.error(error.message);
    }
  }



  return (
    <>
      {isLoading && <Loader />}

      <div className={styles.status}>
        <Card cardClass={styles.card}>
          <h4>Update Status</h4>
          <form onSubmit={(e)=> editOrder(e, id)}>
            <span>
              <select value={status} onChange={(e) => setStatus(e.target.value)}>
                <option value="" disabled>-- Choose one --</option>
                <option value="Oreder Placed...">Oreder Placed...</option>
                <option value="Processing...">Processing...</option>
                <option value="Shipped...">Shipped...</option>
                <option value="Delivered">Delivered</option>
              </select>
            </span>
            <span>
              <button type="submit" className="--btn --btn-primary">
                Update Status
              </button>
            </span>
          </form>
        </Card>
      </div>
    </>

  )
}

export default ChangeOrderStatus;