import './App.scss';




const  App =()=> {
  return (
    <div>
       hi world
       sdcsddc
    </div>
  );
}

export default App;
