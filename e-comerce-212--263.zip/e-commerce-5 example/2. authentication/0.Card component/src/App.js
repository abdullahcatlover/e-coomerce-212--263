import './App.scss';
import {Routes, Route} from 'react-router-dom';
import {Header, Footer, Home, Contact, Login, Register, Reset} from './components/index';


const  App =()=> {
  return (
    <div>
      <Header />
        <Routes>
           <Route path='/' element={<Home />}/>
           <Route path='/contact' element={<Contact />}/>
           <Route path='/login' element={<Login />}/>
           <Route path='/register' element={<Register />}/>
           <Route path='/reset' element={<Reset />}/>
        </Routes>
      <Footer />
    </div>
  );
}



export default App;