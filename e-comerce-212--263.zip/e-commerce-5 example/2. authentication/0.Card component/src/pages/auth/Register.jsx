import React from 'react'

const Register = () => {
  return (
    <div>
        faff
      
    </div>
  )
}

export default Register
