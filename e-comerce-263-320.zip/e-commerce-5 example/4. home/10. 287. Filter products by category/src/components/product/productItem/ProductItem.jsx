import React from 'react'
import styles from './ProductItem.module.scss'
import Card from '../../card/Card'
import { Link } from 'react-router-dom'

const ProductItem = ({ product, grid, id, name, price, desc, imageURL }) => {

  const shortenText = (text, shortText) => {
    if (text.length > shortText) {
      const shortenedText = text.substring(0, shortText).concat("...")
      return shortenedText;
    }
    return text;
  }

  return (
    <Card cardClass={grid ? `${styles.grid}` : `${styles.list}`}>
      <Link to={`/product-details/${id}`}>
        <div className={styles.img}>
          <img src={imageURL} alt={name} />
        </div>
      </Link>

      <div className={styles.content}>
        <div className={styles.details}>
          <p>{`$${price}`}</p>
          <h4>{shortenText(name, 18)}</h4>
        </div>
        {!grid &&
          <p className={styles.desc}>
            {shortenText(desc, 200)}
          </p>
        }

        <button className='--btn --btn-danger'>Add To Card</button>
      </div>
    </Card>
  )

}

export default ProductItem;