import React from 'react'
import './ProductFilter.module.scss'

const ProductItem = () => {
  return (
    <div>ProductItem</div>
  )
}

export default ProductItem