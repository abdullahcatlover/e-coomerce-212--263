import React from 'react'
import './ProductFilter.module.scss'

const ProductList = () => {
  return (
    <div>ProductList</div>
  )
}

export default ProductList