import React from 'react';
import styles from './Product.module.scss';



const Product = () => {
  return (
    <div>
      Product
    </div>
  )
}

export default Product
