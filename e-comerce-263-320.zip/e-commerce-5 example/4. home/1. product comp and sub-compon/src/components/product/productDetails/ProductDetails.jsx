import React from 'react'
import './ProductDetails.module.scss'

const ProductDetails = () => {
  return (
    <div>ProductDetails</div>
  )
}

export default ProductDetails