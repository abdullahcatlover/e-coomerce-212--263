import React from 'react'
import './ProductFilter.module.scss'

const ProductFilter = () => {
  return (
    <div>ProductFilter</div>
  )
}

export default ProductFilter