import React from 'react'
import Slider from '../../components/slider/Slider';
import AdminOlnlyRoute from '../../components/adminOnlyRoute/AdminOlnlyRoute';

const Home = () => {
  return (
    <div>
        <Slider />  
     <h1 className='--btn --btn-primary'>Home page</h1>
   
    </div>
  )
}

export default Home;
