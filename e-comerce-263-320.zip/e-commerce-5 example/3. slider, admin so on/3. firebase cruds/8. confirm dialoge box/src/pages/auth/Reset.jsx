import { useState } from 'react'
import styles from './auth.module.scss'
import resetImg from '../../assets/forgot.png'
import Card from '../../components/card/Card'
import { Link, useNavigate } from 'react-router-dom'
import { sendPasswordResetEmail } from 'firebase/auth'
import { toast } from 'react-toastify'
import { auth } from '../../firebase/config'
import Loader from '../../components/loader/Loader'

const Reset = () => {
  const [email, setEmail] = useState('')
  const [isLoading, setisLoading] = useState(false)

  const navigate = useNavigate()

  const resetPassword = (e) => {
    e.preventDefault()
    setisLoading(true)

    sendPasswordResetEmail(auth, email)
      .then(() => {
        toast.success('Check your email for reset link')
        setisLoading(false)
        navigate('/login')
      })
      .catch((error) => {
        setisLoading(false)
        toast.error(error.message)
      });
  }


  return (
    <>
     {isLoading && <Loader />}
      <section className={`container ${styles.auth}`}>
        <div className={styles.img}>
          <img src={resetImg} alt="Reset password" width='400' />
        </div>
        <Card>
          <div className={styles.form}>
            <h2 className='--color-danger'>Reset Password</h2>
            <form onSubmit={resetPassword}>
              <input
                type="text"
                placeholder='Email
             ' required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <button type='submit' className='--btn --btn-primary --btn-block'>Reset Password</button>

              <div className={styles.links}>
                <p>
                  <Link to='/login'>Login</Link>
                </p>
                <p>
                  <Link to='/register'>Register</Link>
                </p>
              </div>
            </form>
          </div>
        </Card>
      </section>
    </>
  )
}

export default Reset;
