import './App.scss';
import { Routes, Route } from 'react-router-dom';
import { Header, Footer, Home, Contact, Login, Register, Reset, Admin } from './components/index';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import AdminOlnlyRoute from './components/adminOnlyRoute/AdminOlnlyRoute';



const App = () => {
  return (
    <>
      <div>
        <ToastContainer />
        <Header />
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/contact' element={<Contact />} />
          <Route path='/login' element={<Login />} />
          <Route path='/register' element={<Register />} />
          <Route path='/reset' element={<Reset />} />

          <Route path='/admin/*' element={
            <AdminOlnlyRoute>
              <Admin />
            </AdminOlnlyRoute>} />
        </Routes>
        <Footer />
      </div>
    </>
  );
}



export default App;