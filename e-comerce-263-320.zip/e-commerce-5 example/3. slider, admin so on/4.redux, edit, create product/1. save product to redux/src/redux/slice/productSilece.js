import { createSlice } from '@reduxjs/toolkit'

const initialState = {
   products: [],
}

const productSilece = createSlice({
  name: "product",
  initialState,
  reducers: {
    STORE_PRODUCTS(state, action) {
        /*  console.log(action.payload); */
        state.products = action.payload.products
    }
  }
});


export const {STORE_PRODUCTS} = productSilece.actions;

export const selectProducts = (state) => state.product.products;

export default productSilece.reducer