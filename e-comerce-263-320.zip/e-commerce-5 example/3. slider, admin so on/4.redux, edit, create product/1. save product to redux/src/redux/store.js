import {configureStore, combineReducers} from '@reduxjs/toolkit';
import authReducer from './slice/authSlice'
import productReducer from './slice/productSilece'

const rootReducer = combineReducers({
        auth: authReducer,
        product: productReducer,
    })

// combineReducers is gonna contain all of reducers;

const store = configureStore({
    reducer: rootReducer,

})

export default store;