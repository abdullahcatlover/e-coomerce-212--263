import React from 'react'
import Navbar from "../../components/admin/navbar/Navbar"

// import Home from "../../components/admin/home/Home"
import ViewProduct from "../../components/admin/viewProduct/ViewProduct"
import styles from "./admin.module.scss"
import { Route, Routes } from 'react-router-dom'
import AddProduct from '../../components/admin/addProduct/AddProduct'
import Orders from '../../components/admin/orders/Orders'
import Home from '../../components/admin/home/Home'

const Admin = () => {
  return (
    <div className={styles.admin}>
      <div className={styles.navbar}>
        <Navbar />
      </div>

      <div className={styles.content}>
        <Routes>
          <Route path='home' element={<Home />} />
          <Route path='all-products' element={<ViewProduct />} />
          <Route path='add-product/:id' element={<AddProduct />} />
          <Route path='view-orders' element={<Orders />} />
        </Routes>
      </div>
    </div>
  )
}

export default Admin;
