import React from 'react'

const Cheackout = () => {
  return (
    <div>
      <h1 style={{paddingTop: "100px", color: "#000"}}>Cheackout</h1>
    </div>
  )
}

export default Cheackout