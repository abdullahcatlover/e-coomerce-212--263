import './App.scss';
import { Routes, Route } from 'react-router-dom';
import { Header, Footer, Home, Contact, Login, Register, Reset, Admin } from './components/index';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import AdminOlnlyRoute from './components/adminOnlyRoute/AdminOlnlyRoute';
import ProductDetails from './components/product/productDetails/ProductDetails';
import Cart from './pages/cart/Cart';
import CheckOutDetails from './pages/checkout/CheckOutDetails';
import Cheackout from './pages/checkout/Cheackout';



const App = () => {
  return (
    <>
      <div>
        <ToastContainer />
        <Header />
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/contact' element={<Contact />} />
          <Route path='/login' element={<Login />} />
          <Route path='/register' element={<Register />} />
          <Route path='/reset' element={<Reset />} />


          <Route path='/admin/*' element={
            <AdminOlnlyRoute>
              <Admin />
            </AdminOlnlyRoute>
          } />

          <Route path='/product-details/:id' element={<ProductDetails />} />
          <Route path='/cart' element={<Cart />} />
          <Route path='/checkout-details' element={<CheckOutDetails />} />
          <Route path='/checkout' element={<Cheackout/>} />
          
        </Routes>
        <Footer />
      </div>
    </>
  );
}



export default App;