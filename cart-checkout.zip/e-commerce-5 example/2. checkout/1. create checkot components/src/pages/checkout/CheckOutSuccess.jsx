import React from 'react'

const CheckOutSuccess = () => {
  return (
    <div>CheckOutSuccess</div>
  )
}

export default CheckOutSuccess;