import React from 'react'

const Cheackout = () => {
  return (
    <div>Cheackout</div>
  )
}

export default Cheackout