import React from 'react'
import styles from './checkOutDetails.module.scss'

const CheckOutDetails = () => {
  return (
    <div>
       <h2 style={{paddingTop: "100px"}}>CheckOutDetails</h2>
    </div>
  )
}

export default CheckOutDetails