import React, { useEffect, useState } from 'react'
import styles from "./reviewProducts.module.scss"
import { useSelector } from 'react-redux'
import { selectProducts } from '../../redux/slice/productSilece'
import { selectUserID, selectUserName } from '../../redux/slice/authSlice'
import { useNavigate, useParams } from 'react-router-dom'
import Card from '../card/Card'
import StarsRating from 'react-star-rate'
import { db } from "../../firebase/config";
import { addDoc, Timestamp, collection } from "firebase/firestore";
import { toast } from 'react-toastify'
import useFetchDocument from '../../customHooks/useFetchDocument'
import spinnerImg from "../../assets/spinner.jpg"



const ReviewProducts = () => {

  const navigate = useNavigate()
  const [rate, setRate] = useState(0)
  const [review, setReview] = useState("")
  const [product, setProduct] = useState(null)
  const { id } = useParams()
  const { document } = useFetchDocument("products", id)
  const products = useSelector(selectProducts)
  const userId = useSelector(selectUserID)
  const userName = useSelector(selectUserName)



  useEffect(() => {
    setProduct(document)
  }, [document])

  const submitReview = (e) => {
    e.preventDefault()

    const today = new Date()
    const date = today.toDateString()


    const reviewConfig = {
      userId,
      userName,
      productID: id,
      rate,
      review,
      reviewDate: date,
      createdAt: Timestamp.now().toDate()
    }

    try {

      addDoc(collection(db, "reviews"), reviewConfig)

      toast.success("Review submitted successfully")
      setRate(0)
      setReview("")
     // navigate("/order-history")
      

    } catch (error) {
      toast.error(error.message)
    }
  }




  return (
    <section>
      <div className={`container ${styles.review}`}>
        <h2>Review Product</h2>
        {product === null ? (
          <img src={spinnerImg} alt='Loading'  style={{width: "50px"}}/>
        ) : (
          <>
            <p>
              <b>Product Name: </b> {product.name}
            </p>
            <img src={product.imageURL} alt={product.name} style={{ width: "100px" }} />
          </>
        )}

        <Card cardClass={styles.card}>
          <form onSubmit={(e) => submitReview(e)}>
            <label>Rating:</label>
            <StarsRating
              value={rate}
              onChange={rate => {
                setRate(rate)
              }}
            />

            <label>Review</label>
            <textarea onChange={(e) => setReview(e.target.value)}
              value={review}
              required
              cols="30" rows="10">

            </textarea>
            <button type='submit'
              className='--btn --btn-primary'
            >Submit Review</button>
          </form>
        </Card>
      </div>

    </section>
  )
}

export default ReviewProducts;