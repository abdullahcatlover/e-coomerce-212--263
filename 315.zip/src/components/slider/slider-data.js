export const sliderData = [
    {
      image: "https://i.ibb.co/CBGRLhG/bg-4.jpg",
      heading: "Shoes Villa",
      desc: "Up to 30% off on all onsale proucts.",
    },
    {
      image: "https://i.ibb.co/cDLBk5h/bg-1.jpg",
      heading: "Women Fashion",
      desc: "Up to 30% off on all onsale proucts.",
    },
    {
      image: "https://i.ibb.co/HXjD3V0/bg-2.jpg",
      heading: "Men Fashion",
      desc: "Up to 30% off on all onsale proucts.",
    },
    {
      image: "https://i.ibb.co/H2FRmtV/bg-3.jpg",
      heading: "Awesome Gadgets",
      desc: "Up to 30% off on all onsale proucts.",
    },
  ];