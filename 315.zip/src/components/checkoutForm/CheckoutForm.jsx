import React from 'react'
import styles from "./checkoutForm.module.scss"

const CheckoutForm = () => {
  return (
    <div>CheckoutForm</div>
  )
}

export default CheckoutForm