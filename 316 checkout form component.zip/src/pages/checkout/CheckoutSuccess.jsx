import React from 'react'

const CheckoutSuccess = () => {
  return (
    <div>CheckoutSuccess</div>
  )
}

export default CheckoutSuccess