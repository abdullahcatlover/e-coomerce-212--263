import React from 'react'

const ChangeOrderStatus = () => {
  return (
    <div>ChangeOrderStatus</div>
  )
}

export default ChangeOrderStatus;