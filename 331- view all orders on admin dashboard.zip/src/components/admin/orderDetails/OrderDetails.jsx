import React from 'react'

const OrderDetails = () => {
  return (
    <div>
        <h1>OrderDetails</h1>
    </div>
  )
}

export default OrderDetails