import React, { useEffect } from 'react'
import Slider from '../../components/slider/Slider';
import AdminOlnlyRoute from '../../components/adminOnlyRoute/AdminOlnlyRoute';
import Product from '../../components/product/Product';

const Home = () => {
  const url = window.location.href;
   

  const scrollToProducts = () => {
    if (url.includes("#products")) {
      const windowHeight = window.innerHeight;
      const scrollHeight = windowHeight >= 1000 ? 1000 : windowHeight;
  
      window.scrollTo({
        top: scrollHeight,
        behavior: "smooth"
      });
      return;
    }
  }
  

  useEffect(() => {
     scrollToProducts()
  }, [])

  return (
    <div>
        <Slider />  
      <Product />
    
    </div>
  )
}

export default Home;
