import React from 'react'

const CheckoutSuccess = () => {
  return (
    <div>
        <h1>CheckoutSuccess</h1>
    </div>
  )
}

export default CheckoutSuccess